package com.example.myapplication

import androidx.fragment.app.Fragment

class PassRecover : Fragment(R.layout.passwordrecover){

}




