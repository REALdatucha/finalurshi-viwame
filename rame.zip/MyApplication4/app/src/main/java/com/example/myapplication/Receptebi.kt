package com.example.myapplication

data class Receptebi(val image:Int, val name :String, val dec:String, val pas:String)